package com.example.login1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.login1.bdd.BddAyuda;
import com.google.android.material.textfield.TextInputEditText;

public class registrarse extends AppCompatActivity {

     Button btguardar;
     Button btsalir;
     TextInputEditText nombre,apellido,correo,usuario,password;

     BddAyuda ayuda= new BddAyuda(this,"bd1",null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrarse);

        btsalir=findViewById(R.id.btSalir);
        btguardar=findViewById(R.id.btGuardar);
        nombre=findViewById(R.id.TxvNombre);
        apellido=findViewById(R.id.TvApellido);
        correo=findViewById(R.id.TvCorreo);
        usuario=findViewById(R.id.TvUsuarioReg);
        password=findViewById(R.id.Tvcontras);

        btguardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ayuda.abrir();
                ayuda.insertarReg(String.valueOf(nombre.getText()),
                        String.valueOf(apellido.getText()),
                        String.valueOf(correo.getText()),
                        String.valueOf(usuario.getText()),
                        String.valueOf(password.getText()));
                ayuda.cerrar();
                Toast.makeText(getApplicationContext(),"Registro Almacenado con Exito",Toast.LENGTH_LONG).show();

                Intent i = new Intent (getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });

        btsalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

}