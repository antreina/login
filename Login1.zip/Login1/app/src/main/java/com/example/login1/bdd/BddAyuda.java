package com.example.login1.bdd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BddAyuda extends SQLiteOpenHelper {


    //private SQLiteDatabase db;

    public BddAyuda(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query="CREATE TABLE usuarios( ID INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "Nombre TEXT NOT NULL,Apellido TEXT NOT NULL,Correo TEXT NOT NULL,Usuario TEXT,Password TEXT NOT NULL);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //METODO QUE PERMITE ABRIR LA BASE DE DATOS
    public void  abrir(){
        this.getWritableDatabase();
    }



    //METODO QUE PERMITE CERRAR LA BASE DE DATOS
    public void cerrar(){
        this.close();
    }

    //METODO QUE PERMITE INSERTAR REGISTROS EN LA TABLA USUARIOS

    public void insertarReg(String nombre,String apellido,String correo,String usuario,String password){
        ContentValues valores=new ContentValues();
        valores.put("Nombre",nombre);
        valores.put("Apellido",apellido);
        valores.put("Correo",correo);
        valores.put("Usuario",usuario);
        valores.put("Password",password);
        this.getWritableDatabase().insert("usuarios",null,valores);
    }

    //METODO QUE PERMITE VALIDAR SI EL USUARIO EXISTE
    public Cursor Cons_usuario(String usuario,String password) throws SQLException {
        Cursor mcursor;
        mcursor=this.getReadableDatabase().query("usuarios",new String[]{"ID",
                        "Nombre","Apellido","Correo","Usuario","Password"},
                "Usuario LIKE '"+usuario+"' AND Password LIKE '"+password+"'",
                null,null,null,null);
        return mcursor;
    }


}
