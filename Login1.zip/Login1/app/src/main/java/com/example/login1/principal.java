package com.example.login1;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.login1.bdd.BddAyuda;

import java.util.ArrayList;

public class principal extends AppCompatActivity {

    Button consultar,salir;
    EditText nombre;

    ListView lisUsu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        consultar=findViewById(R.id.btConsultarU);
        salir=findViewById(R.id.btSalir);
        lisUsu=findViewById(R.id.ListViewUsuarios);

    }


    //METODO PARA BUSCAR UN USUARIO
    public void consultar(View view) {
        BddAyuda ayuda= new BddAyuda(this,"bd1",null,1);
        SQLiteDatabase baseDatos =ayuda.getWritableDatabase();

    }

    public void salir(View view) {
        finish();
    }
}