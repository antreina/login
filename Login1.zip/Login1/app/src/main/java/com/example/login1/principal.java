package com.example.login1;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.login1.bdd.BddAyuda;

import java.util.ArrayList;

public class principal extends AppCompatActivity {

    Button consultar,salir;
    EditText nombre;

    ListView lisUsu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        consultar=findViewById(R.id.btConsultarU);
        salir=findViewById(R.id.btSalir);
        lisUsu=findViewById(R.id.ListViewUsuarios);

    }


    //METODO PARA BUSCAR UN USUARIO
    public void consultar(View view) {
        BddAyuda ayuda= new BddAyuda(this,"bd1",null,1);
        SQLiteDatabase baseDatos =ayuda.getWritableDatabase();
        if (ayuda !=null){
            Cursor cursor= baseDatos.rawQuery("SELECT * FROM usuarios",null);
            int cantidad = cursor.getCount();
            int i=0;
            String[]arreglo= new String[cantidad];
            if (cursor.moveToFirst()){
                do {
                    String linea = cursor.getString(0)+" "
                            +cursor.getString(1)+" "
                            +cursor.getString(2)+" "
                            +cursor.getString(3)+" "
                            +cursor.getString(4);

                    arreglo[i] = linea;
                            i++;
                }while (cursor.moveToNext());
                ArrayAdapter<String> adapter=new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arreglo);
                lisUsu.setAdapter(adapter);
            }
        }

    }

    public void salir(View view) {
        finish();
    }
}