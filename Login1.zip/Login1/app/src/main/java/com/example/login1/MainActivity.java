package com.example.login1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.login1.bdd.BddAyuda;
import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    TextView registro;
    Button btIngresar;
    EditText usu,pass;
    BddAyuda helper= new BddAyuda(this,"bd1",null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        registro=findViewById(R.id.txtregistroLog);
        btIngresar=findViewById(R.id.btnentrar);

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registro();
            }
        });

        //VALIDACION DE USUARIO Y CONTRASEÑA USANDO LA FUNCION Cursor

        btIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usu=findViewById(R.id.Tlusuario);
                pass=findViewById(R.id.Txtcont);
                try {
                    Cursor cursor= helper.Cons_usuario(usu.getText().toString(),
                            pass.getText().toString());

                    if (cursor.getCount()>0){
                        principal1();
                    }else {
                        Toast.makeText(getApplicationContext(),"Usuario o contraseña incorrectos",
                                Toast.LENGTH_LONG).show();
                    }
                    usu.setText("");
                    pass.setText("");
                    usu.findFocus();
                } catch ( SQLException e){
                    e.printStackTrace();
                }
            }
        });
    }

    //METODO DE INICIO DE LA ACTIVIDAD DE LA PANTALLA DE INICIO DE SESIÓN
    public void registro(){
        Intent i= new Intent(this,registrarse.class);
        startActivity(i);
    }
    //METODO DE INICIO DE LA ACTIVIDAD DE LA PANTALLA PRINCIPAL DEL USUARIO REGISTRADO
    //UNA VEZ VAIDADO EL EL USUARIO Y CONTRASEÑA
    public void principal1(){
        Intent i2= new Intent(this,principal.class);
        startActivity(i2);
    }

}